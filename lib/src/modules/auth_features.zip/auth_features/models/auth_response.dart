class AuthResponse {
  final bool success;
  final String message;

  AuthResponse({
    required this.success,
    required this.message
  });
}